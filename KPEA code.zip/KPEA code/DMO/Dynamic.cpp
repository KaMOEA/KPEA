
#include "global.h"
//#include "dmoeafunc.h"
#include "nsga2func.h"
#include <algorithm>


void execute(char *alg);

void main()
{

	
	int pof[]      = {  21};       // type of pareto front       
	int pos[]      = {  21};       // type of pareto set
	int dis[]      = {   1};       // type of non-negative function
	int var[]      = {  12};       // dimensionality of search spaceά��
	int obj[]      = {   3};       // number of objective functions Ŀ�����
	

	



	// The settings of algorithms
	int pop[] = {100};     // population size
	int gen[] = {100};     // number of generations 300

	
	for(int i=0; i<1; i++)//1ָ����1������������9ָ����9����������
	{
		// the parameter setting of test instance

		/*dtype = dis[i]; 
		ptype = pof[i];  
		ltype = pos[i];*/                  
		nvar  = var[i];
		nobj  = obj[i];


		// the parameter setting of algorithm and 
		pops    = pop[i];
		max_gen = gen[i];

		//sprintf(strTestInstance,"P%dD%dL%d",ptype, dtype, ltype);
		//printf("Instances: pf shape %d  - distance %d, - ps shape %d \n ", ptype, dtype, ltype);
		//execute("DMOEA");

		execute("NSGA-II");
	}
}

void execute(char *alg)
{
	std::fstream fout;
	char filename[1024];
	// compute IGD-values
	sprintf(filename,"GD/GD_NSGA2_%s.dat",strTestInstance);

	fout.open(filename,std::ios::out);

	for(int run=1; run<=max_run; run++) 
	{				
		vector<double> gd;

		 CNSGA2  NSGA2;
		 gd = NSGA2.execute(run);  

		for(int k=0; k<gd.size(); k++)
			fout<<gd[k]<<" ";
		fout<<"\n";
		gd.clear();
	}
	fout.close();
	system("pause");
}