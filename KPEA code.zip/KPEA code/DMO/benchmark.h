#ifndef _BENCHMARK_H_
#define _BENCHMARK_H_

#include "global.h"
#include "nsga2func.h"
#include  <algorithm>
#define pi 3.1415926



void benchmark(vector<double> x_var, vector <double> &y_obj)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =0.0;
		double G = sin(0.5*pi*0);
		for(int n=2;n<nvar;n++)
		{
			gx += (x_var[n]-G)*(x_var[n]-G);
            
		}
		y_obj[0] =(1.0+gx)*cos(0.5*pi*x_var[0])*cos(0.5*pi*x_var[1]);
		y_obj[1] =(1.0+gx)*cos(0.5*pi*x_var[0])*sin(0.5*pi*x_var[1]);
        y_obj[2] =(1.0+gx)*sin(0.5*pi*x_var[0]);

	double a=y_obj[0];
	double b=y_obj[1];
	double c=y_obj[2];



}
void benchmark1(vector<double> x_var, vector <double> &y_obj,double T)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =0.0;
		double G = fabs(sin(0.5*pi*T));
		for(int n=2;n<nvar;n++)
		{
			gx += (x_var[n]-G)*(x_var[n]-G);
            
		}
		y_obj[0] =(1.0+gx)*cos(0.5*pi*x_var[0])*cos(0.5*pi*x_var[1]);
		y_obj[1] =(1.0+gx)*cos(0.5*pi*x_var[1])*sin(0.5*pi*x_var[1]);
        y_obj[2] =(1.0+gx)*sin(0.5*pi*x_var[0]);

	double a=y_obj[0];
	double b=y_obj[1];
	double c=y_obj[2];

} 
void benchmark2(vector<double> x_var, vector <double> &y_obj,double T)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =0.0;
		double G = fabs(sin(0.5*pi*T));
		for(int n=2;n<nvar;n++)
		{
			gx += (x_var[n]-G)*(x_var[n]-G);
            
		}
		gx += G;
		double F =1+100*sin(0.5*pi*T)*sin(0.5*pi*T)*sin(0.5*pi*T)*sin(0.5*pi*T);
	    double y1 = pow(x_var[0],F);
        double y2 = pow(x_var[1],F);    
		
		y_obj[0] =(1.0+gx)*cos(0.5*pi*y1)*cos(0.5*pi*y2);
		y_obj[1] =(1.0+gx)*cos(0.5*pi*y1)*sin(0.5*pi*y2);
        y_obj[2] =(1.0+gx)*sin(0.5*pi*y1);

	double a=y_obj[0];
	double b=y_obj[1];
	double c=y_obj[2];

}

void benchmark3(vector<double> x_var, vector <double> &y_obj,double T,vector<double>yj)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =0.0;
		double G = fabs(sin(0.5*pi*T));
		for(int n=2;n<nvar;n++)
		{
			//double d= floor(x_var[n]-0.001);
			//double e= min(0,d);
		    yj[n] = G+floor(x_var[n]-0.001)*G*(0.001-x_var[n])/0.001-floor(0.05-x_var[n])*(1-G)*(x_var[n]-0.05)/(1-0.05);
			gx += (yj[n]-G)*(yj[n]-G);
            
		}
		gx += G;
		double F =1+100*sin(0.5*pi*T)*sin(0.5*pi*T)*sin(0.5*pi*T)*sin(0.5*pi*T);
	    double y1 = pow(x_var[0],F);
        double y2 = pow(x_var[1],F);    
		
		y_obj[0] =(1.0+gx)*cos(0.5*pi*y1)*cos(0.5*pi*y2);
		y_obj[1] =(1.0+gx)*cos(0.5*pi*y1)*sin(0.5*pi*y2);
        y_obj[2] =(1.0+gx)*sin(0.5*pi*y1);

	double a=y_obj[0];
	double b=y_obj[1];
	double c=y_obj[2];

	

}
void benchmark4(vector<double> x_var, vector <double> &y_obj,double T,vector<double>yj)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =0.0;
		double G = fabs(sin(0.5*pi*T));
		for(int n=2;n<nvar;n++)
		{
			yj[n] = (floor((x_var[n]-G+0.001))*(1-0.05+(G-0.001)/0.001)/(G-0.001)+1/0.001+floor((G+0.001-x_var[n]))*(1-0.05+(1-G-0.001)/0.001)/(1-G-0.001))*(fabs(x_var[n]-G)-0.001)+1;//
            
		}
        for(int n=2;n<nvar;n++)
		{
			gx += (yj[n]-G)*(yj[n]-G);
            
		}
		gx += G;
		double F =1+100*sin(0.5*pi*T)*sin(0.5*pi*T)*sin(0.5*pi*T)*sin(0.5*pi*T);
	    double y1 = pow(x_var[0],F);
        double y2 = pow(x_var[1],F);    
		
		y_obj[0] =(1.0+gx)*cos(0.5*pi*y1)*cos(0.5*pi*y2);
		y_obj[1] =(1.0+gx)*cos(0.5*pi*y1)*sin(0.5*pi*y2);
        y_obj[2] =(1.0+gx)*sin(0.5*pi*y1);

	double a=y_obj[0];
	double b=y_obj[1];
	double c=y_obj[2];

}
void benchmark5(vector<double> x_var, vector <double> &y_obj,double T,vector<double>yj)
{
  		double gx =0.0;
        for(int n=0;n<nvar;n++)
		{
			yj[n] = sin((0.5*pi*T+2*pi*(n/(nvar+1)))*(0.5*pi*T+2*pi*(n/(nvar+1))));
		}
		
		for(int n=2;n<nvar;n++)
		{
			gx = gx+(x_var[n]-yj[n])*(x_var[n]-yj[n])-2*cos(3*pi*(x_var[n]-yj[n]));//
			
		  
		}
        gx =gx+1+2*(nvar-1);//
		y_obj[0] =x_var[0];
		y_obj[1] =gx*g*(1-sqrt(y_obj[0]/gx));

	double a=y_obj[0];
	double b=y_obj[1];
	

} 
void benchmark6(vector<double> x_var, vector <double> &y_obj,double T)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =1;
		double H = 0.75*sin(0.5*pi*T)+1.25;
		double G =sin(0.5*pi*T);
		for(int n=1;n<nvar;n++)
		{
			gx += (x_var[n]-fabs(G))*(x_var[n]-fabs(G));
            
		}
		
		y_obj[0] =x_var[0];
		y_obj[1] = gx*(1-pow(y_obj[0]/gx, H));

	double a=y_obj[0];
	double b=y_obj[1];


}
void benchmark7(vector<double> x_var, vector <double> &y_obj,double T,vector<double>yj)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =1.0;
		double H = 0.75*sin(0.5*pi*T)+1.25;
		double G =sin(0.5*pi*T);
		for(int n=1;n<nvar;n++)
		{
			yj[n] = G+(x_var[n]-0.001)*G*(0.001-x_var[n])/0.001-(0.05-x_var[n])*(1-G)*(x_var[n]-0.05)/(1-0.05);
            
		}
		for(int n=1;n<nvar;n++)
		{
			gx += (x_var[n]-yj[n])*(x_var[n]-yj[n]);
            
		}
		
		y_obj[0] =x_var[0];
		y_obj[1] = gx*(1-pow(y_obj[0]/gx, H));

	double a=y_obj[0];
	double b=y_obj[1];


}
void benchmark8(vector<double> x_var, vector <double> &y_obj,double T,vector<double>yj)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =0.0;
		double H = 0.75*sin(0.5*pi*T)+1.25;
		double G =sin(0.5*pi*T);
		for(int n=1;n<nvar;n++)
		{
			yj[n] = (floor((x_var[n]-G+0.001))*(1-0.05+(G-0.001)/0.001)/(G-0.001)+1/0.001+floor((G+0.001-x_var[n]))*(1-0.05+(1-G-0.001)/0.001)/(1-G-0.001))*(fabs(x_var[n]-G)-0.001)+1;//
		}
		for(int n=1;n<nvar;n++)
		{
			gx = gx+(x_var[n]-yj[n])*(x_var[n]-yj[n]);
            
		}
		gx = gx +1;
		y_obj[0] =x_var[0];
		y_obj[1] = gx*(1-pow(y_obj[0]/gx, H));

	double a=y_obj[0];
	double b=y_obj[1];


}
void benchmark9(vector<double> x_var, vector <double> &y_obj,double T)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =0.0;
		double H = 0.75*sin(0.5*pi*T)+1.25;
		double G =sin(0.5*pi*T);
		for(int n=1;n<nvar;n++)
		{
			gx += (x_var[n]-fabs(G))*(x_var[n]-fabs(G));
            
		}
		gx = gx+1.0;
		y_obj[0] =x_var[0];
		y_obj[1] = gx*(1-pow(y_obj[0]/gx, 0.5));

	double a=y_obj[0];
	double b=y_obj[1];


}
void benchmark10(vector<double> x_var, vector <double> &y_obj,double T)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =1.0;
		double H = 0.75*sin(0.5*pi*T)+1.25;
		for(int n=1;n<nvar;n++)
		{
			gx += 9/(nvar-1)*x_var[n];
            
		}
		
		y_obj[0] =x_var[0];
		y_obj[1] = gx*(1-pow(y_obj[0]/gx, (0.5*H))-pow(y_obj[0]/gx, H)*sin(10*pi*y_obj[0]));

	double a=y_obj[0];
	double b=y_obj[1];


}
void benchmark11(vector<double> x_var, vector <double> &y_obj,double T)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =0.0;
		double fx=0.0;
		double H = 0.75*sin(0.5*pi*T)+1.25;
		for(int n=1;n<nvar;n+=2)
		{
			fx += 2/abs(nvar)*(x_var[n]-(0.3*x_var[0]*x_var[0]*cos(24*pi*x_var[0]+4*n*pi/nvar))+0.6*x_var[0])*cos((6*pi*x_var[0]+n*pi/nvar)*(6*pi*x_var[0]+n*pi/nvar));
            
		}
        for(int n=0;n<nvar;n+=2)
		{
			gx += 2/abs(nvar)*(x_var[n]-(0.3*x_var[0]*x_var[0]*cos(24*pi*x_var[0]+4*n*pi/nvar))+0.6*x_var[0])*sin((6*pi*x_var[0]+n*pi/nvar)*(6*pi*x_var[0]+n*pi/nvar));
            
		}
		gx= gx+2-pow(x_var[0],0.5);
		
		y_obj[0] =x_var[0]+fx;
		y_obj[1] = gx*(1-pow(fx/gx, H));

	double a=y_obj[0];
	double b=y_obj[1];


}
void benchmark12(vector<double> x_var, vector <double> &y_obj,double T)
{

    /*if(!strcmp(strTestInstance,"F1"))
	{*/
		double gx =0.0;
		double fx=0.0;
		double H = 0.75*sin(0.5*pi*T)+1.25;
		for(int n=0;n<nvar;n++)
		{
			fx += 2/5*(x_var[2]-sin(6*pi*x_var[0]+3*pi/nvar))*(x_var[2]-sin(6*pi*x_var[0]+3*pi/nvar));//+2/5*(x_var[4]-sin(6*pi*x_var[0]+5*pi/nvar))*(x_var[4]-sin(6*pi*x_var[0]+5*pi/nvar))+2/5*(x_var[6]-sin(6*pi*x_var[0]+7*pi/nvar))*(x_var[6]-sin(6*pi*x_var[0]+7*pi/nvar))+2/5*(x_var[8]-sin(6*pi*x_var[0]+9*pi/nvar))*(x_var[8]-sin(6*pi*x_var[0]+9*pi/nvar))+2/5*(x_var[10]-sin(6*pi*x_var[0]+11*pi/nvar))*(x_var[10]-sin(6*pi*x_var[0]+11*pi/nvar));
            
		}
        for(int n=0;n<nvar;n++)
		{
			gx += 2/5*(x_var[1]-sin(6*pi*x_var[0]+2*pi/nvar))*(x_var[1]-sin(6*pi*x_var[0]+2*pi/nvar))+2/5*(x_var[3]-sin(6*pi*x_var[0]+4*pi/nvar))*(x_var[3]-sin(6*pi*x_var[0]+4*pi/nvar))+2/5*(x_var[5]-sin(6*pi*x_var[0]+6*pi/nvar))*(x_var[5]-sin(6*pi*x_var[0]+6*pi/nvar))+2/5*(x_var[7]-sin(6*pi*x_var[0]+8*pi/nvar))*(x_var[7]-sin(6*pi*x_var[0]+8*pi/nvar))+2/5*(x_var[9]-sin(6*pi*x_var[0]+10*pi/nvar))*(x_var[9]-sin(6*pi*x_var[0]+10*pi/nvar));
            
		}
		gx= gx+2-x_var[0]*x_var[0];
		fx+=x_var[0];
		y_obj[0] =fx;
		y_obj[1] = gx*(1-pow(fx/gx, H));

	double a=y_obj[0];
	double b=y_obj[1];


}



#endif
