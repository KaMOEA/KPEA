
#include "global.h"
//#include "dmoeafunc.h"
#include "nsga2func.h"
#include <random>


void execute(char *alg);

void main()
{

	// The settings of test instances F1-F9
	// char *ins[] = {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9"}
	
	
	int var[]      = {  12};      
	int obj[]      = {   2};       
	

	



	// The settings of algorithms
	int pop[] = {100};     // population size
	int gen[] = {100};     // number of generations 300

	
	for(int i=0; i<1; i++)//
	{
		// the parameter setting of test instance

		/*dtype = dis[i]; 
		ptype = pof[i];  
		ltype = pos[i];*/                  
		nvar  = var[i];
		nobj  = obj[i];


		// the parameter setting of algorithm and 
		pops    = pop[i];
		max_gen = gen[i];
         
		//sprintf(strTestInstance,"P%dD%dL%d",ptype, dtype, ltype);
		//printf("Instances: pf shape %d  - distance %d, - ps shape %d \n ", ptype, dtype, ltype);
		//execute("DMOEA");
        for (int k = nobj - 1; k < tnvar; k++)
		{
			lowBound[k] = lb, uppBound[k] = ub;
		}

		//pops = pop[i];
		max_gen = 50 + 3 * nt*taut;
		execute("NSGA-II");
	}
}

void execute(char *alg)
{
	std::fstream fout;
	char filename[1024];
	// compute IGD-values
	sprintf(filename,"NSGA2_%s.dat",strTestInstance);

	fout.open(filename,std::ios::out);

	for(int run=1; run<=max_run; run++) 
	{				
		vector<double> gd;

		 CNSGA2  NSGA2;
		 gd = NSGA2.execute(run);  

		for(int k=0; k<gd.size(); k++)
			fout<<gd[k]<<" ";
		fout<<"\n";
		gd.clear();
	}
	fout.close();
	system("pause");
}